package Doubly;
import Doubly.Node;


public class Tester {
	public static void main(String[] args) {
		DoublyLinkedList dList= new DoublyLinkedList();
		dList.addAtEnd(10);
		dList.addAtEnd(20);
		dList.addAtEnd(30);
		dList.addAtEnd(40);
		dList.display();
		dList.rdisplay();
	}
}
