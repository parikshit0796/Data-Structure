package Doubly;

public class DoublyLinkedList {
	private Node head,tail;
	
	public DoublyLinkedList() {
		head=tail=null;
	}
	
	public void addAtEnd(int data) {
		Node newNode =new Node();
		newNode.setPrev(null);
		newNode.setData(data);
		newNode.setNext(null);
		
		if(head==null && tail==null) {
			head=tail=newNode;
		}
		else {
			tail.setNext(newNode);
			newNode.setPrev(tail);
			tail=newNode;
		}
	}
	
	public void display () {
		Node trav=head;
		while(trav!=null) {
			System.out.print(trav.getData()+ " ");
			trav=trav.getNext();
		}
		System.out.println(" ");
	}
	
	public void rdisplay () {
		Node trav=tail;
		while(trav!=null) {
			System.out.print(trav.getData()+ " ");
			trav=trav.getPrev();
		}
		System.out.println(" ");
	}

}
