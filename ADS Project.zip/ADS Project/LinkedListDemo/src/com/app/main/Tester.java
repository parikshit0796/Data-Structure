package com.app.main;

import com.app.linkedlist.LinkedList;

public class Tester {

	public static void main(String[] args) {
		LinkedList l1= new LinkedList();
		l1.addAtEnd(12);
		l1.addAtEnd(124);
		l1.addAtEnd(10);
		l1.addAtEnd(66);
		l1.show();
		System.out.println();
		l1.addAtBegin(5);
		l1.addAtPosition(20, 2);
		l1.show();
		System.out.println();
		l1.removeFromBegin();
		l1.show();
		System.out.println();
		l1.removeFromEnd();
	    l1.removeFromPosition(2);
		l1.show();
		System.out.println();
	}

}
